package l2jorion.game.autofarm;

public enum AutofarmSpellType
{
	Attack,
	Chance,
	Self,
	LowLife
}
